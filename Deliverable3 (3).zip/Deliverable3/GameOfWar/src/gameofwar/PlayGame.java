package gameofwar;

/**
 * Run this to start the game.
 */
public class PlayGame {
    public static void main(String args[]){
        TheWar game = new TheWar();
        game.play();
         
  
    }
    
}
