
package gameofwar;


public abstract class Card 
{

    
    @Override
    public abstract String toString();
    
}
